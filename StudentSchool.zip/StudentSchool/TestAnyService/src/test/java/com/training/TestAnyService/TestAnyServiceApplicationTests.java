package com.training.TestAnyService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestAnyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
