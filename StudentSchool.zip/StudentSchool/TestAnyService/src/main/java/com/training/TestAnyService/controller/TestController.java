package com.training.TestAnyService.controller;

import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.TestAnyService.model.School;
import com.training.TestAnyService.service.SchoolTestService;

@RestController
public class TestController {

	@Autowired
	SchoolTestService testService;

	//all school data
	@GetMapping("/schools")
	public ResponseEntity<List> findAll() throws URISyntaxException {
		//LOGGER.debug("Getting all the employees.");
		return new ResponseEntity<List>(testService.findAll(),HttpStatus.OK);
	}	
	
	//school data by id
	@GetMapping("/schoolById")
	public ResponseEntity<School> findAllBySchoolId(@RequestParam int sid) throws URISyntaxException{
		//LOGGER.debug("Getting employee by id.");
		return new ResponseEntity<School>(testService.findBySchoolId(sid),HttpStatus.OK);
	}
		
}