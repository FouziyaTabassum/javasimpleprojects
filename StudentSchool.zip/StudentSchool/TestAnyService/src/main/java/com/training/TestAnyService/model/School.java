package com.training.TestAnyService.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class School {

	private int id;
	private String name;
	private int schoolRank;
	private String location;
	private boolean isTransportAvailable;
	private List<Student> studentList;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSchoolRank() {
		return schoolRank;
	}
	public void setSchoolRank(int schoolRank) {
		this.schoolRank = schoolRank;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public boolean isTransportAvailable() {
		return isTransportAvailable;
	}
	public void setTransportAvailable(boolean isTransportAvailable) {
		this.isTransportAvailable = isTransportAvailable;
	}
	public List<Student> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}
	@Override
	public String toString() {
		return "School [id=" + id + ", name=" + name + ", schoolRank=" + schoolRank + ", location=" + location
				+ ", isTransportAvailable=" + isTransportAvailable + ", studentList=" + studentList + "]";
	}
	
	

}