package com.training.TestAnyService.service;

import java.net.URISyntaxException;
import java.util.List;

import com.training.TestAnyService.model.School;

public interface SchoolTestService {

	public List<School> findAll() throws URISyntaxException;
	public School findBySchoolId(int sid) throws URISyntaxException;


}
