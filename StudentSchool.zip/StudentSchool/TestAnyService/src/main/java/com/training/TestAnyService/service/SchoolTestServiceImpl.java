package com.training.TestAnyService.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.training.TestAnyService.model.School;
import com.training.TestAnyService.model.Student;

@Service
public class SchoolTestServiceImpl implements SchoolTestService{
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public List<School> findAll() throws URISyntaxException {
	
		final String schoolUrl = "http://SchoolService/schools";
		URI schoolURI = new URI(schoolUrl);

		ResponseEntity<School[]> schoolResult = restTemplate.getForEntity(schoolURI, School[].class);

		School[] schoolList = schoolResult.getBody();

		for (School sch : Arrays.asList(schoolList)) {
			final String studentUrl = "http://StudentService/student?id=" + sch.getId();
			URI studentURI = new URI(studentUrl);

			ResponseEntity<Student[]> studentResult = restTemplate.getForEntity(studentURI, Student[].class);

			Student[] studentList = studentResult.getBody();

			sch.setStudentList(Arrays.asList(studentList));

		}
		return Arrays.asList(schoolList);
	}

	@Override
    public School findBySchoolId(int id) throws URISyntaxException {
        final String schoolUrl = "http://SchoolService/school?id="+id;
        URI schoolURI = new URI(schoolUrl);
        ResponseEntity<School> schoolResult = restTemplate.getForEntity(schoolURI, School.class);
        
        School schoolList = schoolResult.getBody();
        
        for (School scl : Arrays.asList(schoolList)) {
            final String studentUrl = "http://StudentService/studentsBySchool?sid=" + scl.getId();
            URI studentURI = new URI(studentUrl);
            
            ResponseEntity<Student[]> studentResult = restTemplate.getForEntity(studentURI, Student[].class);

            Student[] studentList = studentResult.getBody();

            scl.setStudentList(Arrays.asList(studentList));;

         }
        
        return schoolList;
    }
}
