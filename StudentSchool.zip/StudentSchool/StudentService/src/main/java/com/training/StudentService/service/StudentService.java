package com.training.StudentService.service;

import java.util.List;

import com.training.StudentService.model.Student;

public interface StudentService {
	
	public List<Student> findAll();
	public Student findById(int id);
	public boolean deleteById(int id);
	public Student save(Student stu);
	public List<Student> findAllBySchoolId(int id);

}
