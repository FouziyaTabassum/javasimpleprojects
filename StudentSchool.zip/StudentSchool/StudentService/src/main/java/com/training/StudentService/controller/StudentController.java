package com.training.StudentService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.StudentService.model.Student;
import com.training.StudentService.service.StudentService;


@RestController
public class StudentController {

	@Autowired
	StudentService stuService;

	@GetMapping("/students")
	public ResponseEntity<List> students() {
		//LOGGER.debug("Getting all the employees.");
		return new ResponseEntity<List>(stuService.findAll(),HttpStatus.OK);
	}		

	@GetMapping("/student")
	public ResponseEntity<Student> student(@RequestParam int id) {
		//LOGGER.debug("Getting employee by id.");
		return new ResponseEntity<Student>(stuService.findById(id),HttpStatus.OK);
	}	

	@PostMapping("/student")
	public ResponseEntity<Student> create(@RequestBody Student stu) {
		//LOGGER.debug("Creating a new employee.");
		return new ResponseEntity<Student>(stuService.save(stu),HttpStatus.CREATED);
	}

	@PutMapping("/student")
	public ResponseEntity<Student> update(@RequestBody Student stu) {
		//LOGGER.debug("Updating employee.");
		return new ResponseEntity<Student>(stuService.save(stu),HttpStatus.OK);
	}

	@DeleteMapping("/student")
	public ResponseEntity<Boolean> delete(@RequestParam int id) {
		//LOGGER.debug("Deleting employee.");
		return new ResponseEntity<Boolean>(stuService.deleteById(id),HttpStatus.OK);
	}
	
	//all students by schoolId
	@GetMapping("/studentsBySchool")
	public ResponseEntity<List> studentBySchoolId(@RequestParam int id) {
		//LOGGER.debug("Getting employee by id.");
		return new ResponseEntity<List>(stuService.findAllBySchoolId(id),HttpStatus.OK);
	}

}
