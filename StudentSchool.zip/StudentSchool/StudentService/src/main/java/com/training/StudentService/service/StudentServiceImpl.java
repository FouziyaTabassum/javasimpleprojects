package com.training.StudentService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.StudentService.model.Student;
import com.training.StudentService.repo.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository stuRepo;

	@Override
	public List<Student> findAll() {
//		EmployeeController.Logger.debug("Retreivig all employee data from service method..");
		return stuRepo.findAll();
	}

	@Override
	public Student findById(int id) {
		return stuRepo.findById(id).orElse(null);
	}

	@Override
	public boolean deleteById(int id) {
		stuRepo.deleteById(id);
		return true;
	}

	@Override
	public Student save(Student stu) {
		return stuRepo.save(stu);
	}

	@Override
	public List<Student> findAllBySchoolId(int sid) {
		return stuRepo.findAllBySchoolId(sid);
	}

}

