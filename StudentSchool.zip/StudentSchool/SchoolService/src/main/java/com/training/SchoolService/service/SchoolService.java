package com.training.SchoolService.service;

import java.util.List;

import com.training.SchoolService.model.School;

public interface SchoolService {

	public List<School> findAll();
	public School findById(int id);
	public boolean deleteById(int id);
	public School save(School sch);
}
