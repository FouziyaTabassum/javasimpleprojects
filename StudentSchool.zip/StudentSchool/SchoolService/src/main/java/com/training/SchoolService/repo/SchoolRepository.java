package com.training.SchoolService.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.training.SchoolService.model.School;


@Repository
public interface SchoolRepository extends JpaRepository<School, Integer>{

}