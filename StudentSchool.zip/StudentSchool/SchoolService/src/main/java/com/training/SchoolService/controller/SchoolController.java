package com.training.SchoolService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.SchoolService.model.School;
import com.training.SchoolService.service.SchoolService;


@RestController
public class SchoolController {

	@Autowired
	SchoolService schService;

	@GetMapping("/schools")
	public ResponseEntity<List> schools() {
		//LOGGER.debug("Getting all the employees.");
		return new ResponseEntity<List>(schService.findAll(),HttpStatus.OK);
	}		

	@GetMapping("/school")
	public ResponseEntity<School> school(@RequestParam int id) {
		//LOGGER.debug("Getting employee by id.");
		return new ResponseEntity<School>(schService.findById(id),HttpStatus.OK);
	}	

	@PostMapping("/school")
	public ResponseEntity<School> create(@RequestBody School m) {
		//LOGGER.debug("Creating a new employee.");
		return new ResponseEntity<School>(schService.save(m),HttpStatus.CREATED);
	}

	@PutMapping("/school")
	public ResponseEntity<School> update(@RequestBody School m) {
		//LOGGER.debug("Updating employee.");
		return new ResponseEntity<School>(schService.save(m),HttpStatus.OK);
	}

	@DeleteMapping("/school")
	public ResponseEntity<Boolean> delete(@RequestParam int id) {
		//LOGGER.debug("Deleting employee.");
		return new ResponseEntity<Boolean>(schService.deleteById(id),HttpStatus.OK);
	}

}
