package com.training.SchoolService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.SchoolService.model.School;
import com.training.SchoolService.repo.SchoolRepository;

@Service
public class SchoolServiceImpl implements SchoolService{
	
	@Autowired
	SchoolRepository schRepo;

	@Override
	public List<School> findAll() {
//		EmployeeController.Logger.debug("Retreivig all employee data from service method..");
		return schRepo.findAll();
	}

	@Override
	public School findById(int id) {
		return schRepo.findById(id).get();
	}

	@Override
	public boolean deleteById(int id) {
		schRepo.deleteById(id);
		return true;
	}

	@Override
	public School save(School sch) {
		return schRepo.save(sch);
	}


}

