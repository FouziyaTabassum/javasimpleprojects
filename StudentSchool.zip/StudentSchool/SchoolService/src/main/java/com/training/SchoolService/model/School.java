package com.training.SchoolService.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class School {
	@Id
	private int id;
	private String name;
	private int schoolRank;
	private String location;
	private boolean isTransportAvailable;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSchoolRank() {
		return schoolRank;
	}
	public void setSchoolRank(int schoolRank) {
		this.schoolRank = schoolRank;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public boolean isTransportAvailable() {
		return isTransportAvailable;
	}
	public void setTransportAvailable(boolean isTransportAvailable) {
		this.isTransportAvailable = isTransportAvailable;
	}
	@Override
	public String toString() {
		return "School [id=" + id + ", name=" + name + ", schoolRank=" + schoolRank + ", location=" + location
				+ ", isTransportAvailable=" + isTransportAvailable + "]";
	}
	
	

}